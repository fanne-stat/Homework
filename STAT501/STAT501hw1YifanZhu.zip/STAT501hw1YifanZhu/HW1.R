
setwd("c:/Users/fanne/Dropbox/Homework/STAT501/STAT501hw1YifanZhu/")
#Problem 1

#a) Read the dataset
install.packages("readxl")
library(readxl)
senators<-read_xls("senate_voting_data.xls")

#b) Use Andrews' curves
install.packages("andrews")
library(andrews)

senators.names<-names(senators)[-c(1,2)]
rev.party.state.names<-lapply(X=strsplit(gsub(pattern="[.]",replacement="",x=senators.names),split=" "),FUN = rev)

senators.party <- lapply(X = rev.party.state.names, FUN = function(x)(unlist(x)[1]))
senators.party <- unlist(senators.party)

senators.last.names <- lapply(X = rev.party.state.names, FUN = function(x)(unlist(x)[4]))
senators.last.names <- unlist(senators.last.names)


senators_new <- as.data.frame(t(senators[,-c(1,2)]))

colnames(senators_new) <- NULL
rownames(senators_new) <- NULL

senators_new <- data.frame(senators_new, party = senators.party)


source("ggandrews.R")
ggandrews(senators_new, type = 2, clr = 543, linecol = c("blue", "purple", "red")) 




#Problem 2
install.packages("lattice")
install.packages("dprep")
library(dprep)
#a) Radial visualization
sclerosis <- read.table("sclerosis.dat", header=F)

p <- dim(sclerosis)[2]
sclerosis[, p] <- as.factor(ifelse(sclerosis[,p] == 0, "normal", "sclerosis"))

colnames(sclerosis) <- c("Age", "TS1", "DS1", "TS2", "DS2", "Disease")

source("radviz2d.R")

radviz2d(dataset = sclerosis, name = "Sclerosis")

source("starcoord.R")

starcoord(data = sclerosis, class = TRUE)


#b) Calculate the mean
normal_mean<-colMeans(sclerosis[sclerosis[,p]=="normal", -p])
normal_mean

sclerosis_mean<-colMeans(sclerosis[sclerosis[,p]=="sclerosis", -p])
sclerosis_mean

# sclerosis_mean_data <- as.matrix(rbind(normal_mean, sclerosis_mean))



#c) Display the means
install.packages("TeachingDemos")
library(TeachingDemos)
faces(sclerosis_mean_data, labels = c("normal", "sclerosis"))

#d) plotcorr
source("plotcorr.R")
par(mfrow = c(1,2))
plot.corr(xx = sclerosis[sclerosis[,p]=="normal", -p])
title(sub = "normal")
plot.corr(xx = sclerosis[sclerosis[,p]=="sclerosis", -p])
title(sub = "sclerosis")

